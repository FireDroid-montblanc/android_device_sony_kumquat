#!/system/bin/sh
touch /cache/recovery/boot;
sync;
reboot;
